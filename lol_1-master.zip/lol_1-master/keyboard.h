#ifndef KEYBOARD_H__
#define KEYBOARD_H__


// Define mode part
#define ZERO 48
#define ONE 49
#define TWO 50
#define THREE 51
#define FOUR 52
#define FIVE 53
#define SIX 54
#define SEVEN 55
#define EIGHT 56


// Define action  part



// Define exit
#define ESC 27
#endif